const el = id => document.getElementById(id);
const view = el('radar').getContext('2d');
const mapMenu = el('map'), rounds = el('round'), scene = el('scene'), slider = el('scrub');
const landmarks = [
  ['Быстрый выход на A','nuke',1,20], ['Ложный B и отзыв резерва','ancient-fake',1,12],
  ['Гибель пары на A и полная перетяжка','ancient',2,38], ['Разные входы и флешки на B','cache',2,54],
  ['Ожидание союзника','ancient',7,42], ['Переключение атаки и отход CT','dust2',19,45],
  ['Парный поджим','ancient',17,9], ['Размен','ancient',5,34],
  ['Огонь по укрытию','train',3,44], ['Дым и прикрытие разминирования','vertigo',1,53],
];
for (const name of Object.keys(records)) mapMenu.add(new Option(name === 'ancient-fake' ? 'Ancient · фейк' : name, name));
landmarks.forEach(([text], i) => scene.add(new Option(text, i)));
let match, round, backgrounds = {}, timer, choice = 0;
function pause() { clearInterval(timer); timer = null; el('play').textContent = 'Смотреть'; }
function loadRound(number, second = 0) {
  pause(); rounds.value = number; round = match.rounds[number - 1];
  slider.max = round.frames.length - 1;
  const at = round.frames.findIndex(f => f[0] >= round.start + 10 * second);
  slider.value = at < 0 ? slider.max : at;
  el('formation').textContent = round.setup;
  el('summary').textContent = 'Правила .18 · seed ' + match.seed + ' · ' + match.rounds.length + ' раундов · шаг записи 0,5 с';
  draw();
}
async function loadMap(name, number = 1, second = 0) {
  pause(); const serial = ++choice; mapMenu.value = name;
  const bytes = Uint8Array.from(atob(records[name]), c => c.charCodeAt(0));
  const decoded = await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).json();
  if (serial !== choice) return;
  match = decoded; backgrounds = {}; rounds.replaceChildren();
  for (const r of match.rounds) rounds.add(new Option(r.n, r.n));
  const id = match.map.substring(3);
  const layers = levels[id] ? ['default','lower'] : ['default'];
  el('floorLabel').hidden = layers.length === 1; el('floor').value = 'default';
  for (const layer of layers) {
    const pic = new Image(); backgrounds[layer] = pic;
    pic.onload = () => { if (serial === choice) draw(); };
    pic.src = id + (layer === 'lower' ? '_lower' : '') + '.webp';
  }
  loadRound(number, second);
}
function draw() {
  if (!round) return;
  const index = Number(slider.value), frame = round.frames[index], layer = el('floor').value;
  const factor = 768 * 12 / (1024 * match.scale);
  const bounds = levels[match.map.substring(3)]?.[layer];
  function here(z) { return !bounds || z * 12 >= Number(bounds.AltitudeMin) && z * 12 < Number(bounds.AltitudeMax); }
  view.clearRect(0,0,768,768);
  const bg = backgrounds[layer]; if (bg?.naturalWidth) view.drawImage(bg,0,0,768,768);
  el('jobs').replaceChildren();
  round.agents.forEach(([id,side,name], i) => {
    const [x,y,z,hp,status] = frame[2][i];
    if (side === 'CT' && hp > 0) {
      const line = document.createElement('li'); line.textContent = name + ' · ' + status; el('jobs').append(line);
    }
    if (!hp || !here(z)) return;
    view.strokeStyle = view.fillStyle = side === 'CT' ? '#78dcff' : '#ffc172';
    view.lineWidth = 2; view.beginPath(); let pen = false;
    for (const previous of round.frames.slice(Math.max(0,index-8),index+1)) {
      const p = previous[2][i];
      if (!here(p[2])) { pen = false; continue; }
      if (pen) view.lineTo(p[0]*factor,p[1]*factor); else view.moveTo(p[0]*factor,p[1]*factor);
      pen = true;
    }
    view.stroke(); view.beginPath(); view.arc(x*factor,y*factor,5,0,Math.PI*2); view.fill();
    view.font='bold 13px sans-serif'; view.strokeStyle='#172126'; view.lineWidth=3;
    view.strokeText(name,x*factor+7,y*factor-3); view.fillText(name,x*factor+7,y*factor-3);
  });
  const seconds = t => ((t-round.start)/10).toFixed(1);
  el('clock').textContent = seconds(frame[0]) + ' с';
  el('log').replaceChildren();
  const last = index === Number(slider.max);
  for (const e of round.events.filter(e => (e.tick <= frame[0] || last) && !['contact','plan','flash'].includes(e.kind)).slice(-7)) {
    const line = document.createElement('li'); line.textContent = seconds(e.tick)+' с · '+e.text+(e.purpose ? ' · '+e.purpose : '');
    el('log').append(line);
  }
}
scene.onchange = () => { if (scene.value !== '') { const [,m,n,t]=landmarks[Number(scene.value)]; loadMap(m,n,t); } };
mapMenu.onchange = () => {scene.value='';loadMap(mapMenu.value);};
rounds.onchange = () => {scene.value='';loadRound(Number(rounds.value));};
el('floor').onchange = draw; slider.oninput = draw;
el('play').onclick = () => {
  if(timer) { pause(); return; }
  if(slider.value===slider.max) slider.value=0;
  const start=performance.now(), initial=Number(slider.value), rate=Number(el('speed').value);
  el('play').textContent='Пауза';
  timer=setInterval(()=>{slider.value=Math.min(Number(slider.max),initial+Math.floor((performance.now()-start)*rate/500));draw();if(slider.value===slider.max)pause();},60);
};
scene.value='3'; loadMap('cache',2,54);

"""Read the archived pre-radio states with the selected version of backend on PYTHONPATH."""
import argparse
from math import dist
from pathlib import Path
import gzip
import json

from backend import cs2_defense, cs2_maps, match

def replay(row):
    game = row["w"]
    start = game["tick"] + 1
    distances = {}
    order = movement = None
    while game["phase"] == "live" and game["tick"] < start + 50 and movement is None:
        match.advance(game)
        for actor in game["agents"]:
            if actor["team"] != "CT" or not actor["hp"]:
                continue
            duty = cs2_defense.relief(game["plans"]["CT"], actor)
            ident = actor["id"]
            if not duty or duty["site"] != row["site"]:
                distances.pop(ident, None)
                continue
            if order is None:
                order = game["tick"] - start
            gap = dist(cs2_maps.xyz(actor), duty["hold"])
            if distances.setdefault(ident, gap) - gap >= 6:
                movement = game["tick"] - start
                break
    return dict(map=game["mapId"], round=game["round"], at=start, site=row["site"],
                sender=row["sender"], contact=row["contact"], order=order, movement=movement)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkpoint", type=Path)
    args = parser.parse_args()
    with gzip.open(args.checkpoint, "rt", encoding="utf-8") as file:
        print(json.dumps([replay(row) for row in json.load(file)], ensure_ascii=False))

const $=id=>document.getElementById(id), map=$('maps'), scene=$('case'), slider=$('scrub'), floor=$('floor'),ctx=$('view').getContext('2d');
let sequence,timer,bg,cat='';
function pause(){clearInterval(timer);timer=null;$('play').textContent='Смотреть'}
function load(){pause();sequence=radar.examples.find(o=>o.map===map.value&&o.kind===scene.value);cat=sequence.kind;slider.max=sequence.frames.length-1;slider.value=0;
 const focus=sequence.agents.findIndex(p=>p[0]===sequence.focus[0]),z=sequence.frames[Math.floor(sequence.frames.length/2)][1][focus][2]*12;
 const low=radar.maps[map.value].levels.lower;floor.value=low&&z>=+low.AltitudeMin&&z<+low.AltitudeMax?'lower':'default';
 $('title').textContent=sequence.label;$('ctx').textContent=(sequence.fake?'Заданная тактика T':'Обычный BO1')+' · seed '+sequence.seed+' · раунд '+sequence.round+' · '+sequence.formation;$('text').textContent=sequence.text;picture();}
function picture(){bg=new Image();bg.onload=draw;bg.src=map.value+(floor.value==='lower'?'_lower':'')+'.webp';draw()}
function lists(id,texts){$(id).replaceChildren(...texts.map(x=>{const e=document.createElement('li');e.textContent=x;return e}))}
function draw(){if(!sequence)return;const f=+slider.value,[t,agents]=sequence.frames[f],config=radar.maps[map.value],bound=config.levels[floor.value],scale=768*12/(1024*config.scale);
 const here=p=>!bound||p[2]*12>=+bound.AltitudeMin&&p[2]*12<+bound.AltitudeMax;
 ctx.clearRect(0,0,768,768);if(bg?.naturalWidth)ctx.drawImage(bg,0,0,768,768);
 sequence.agents.forEach(([id,n,side],i)=>{const p=agents[i];if(!p[4]||!here(p))return;ctx.strokeStyle=ctx.fillStyle=side==='CT'?'#8be1ff':'#ffc18c';
 ctx.beginPath();let pen=false;for(const [,ps] of sequence.frames.slice(Math.max(0,f-8),f+1)){if(!here(ps[i])){pen=false;continue}ctx[pen?'lineTo':'moveTo'](ps[i][0]*scale,ps[i][1]*scale);pen=true}ctx.lineWidth=2;ctx.stroke();const x=p[0]*scale,y=p[1]*scale,focus=sequence.focus.includes(id);
 ctx.beginPath();ctx.arc(x,y,focus?6:4,0,2*Math.PI);ctx.fill();ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+20*Math.cos(p[3]),y+20*Math.sin(p[3]));ctx.stroke();if(focus){ctx.font='bold 14px system-ui';ctx.lineWidth=3;ctx.strokeStyle='#1a252e';ctx.strokeText(n,x+7,y-7);ctx.fillText(n,x+7,y-7)}});
 $('time').textContent=(t/10).toFixed(1)+' с';lists('players',sequence.agents.flatMap(([id,n],i)=>sequence.focus.includes(id)?[n+' · '+agents[i][5]]:[]));
 lists('log',sequence.events.filter(e=>e[0]<=t).slice(-7).map(e=>(e[0]/10).toFixed(1)+' с · '+e[1]));}
function select(){scene.replaceChildren(...radar.examples.filter(o=>o.map===map.value).map(o=>new Option(o.label,o.kind)));if([...scene.options].some(o=>o.value===cat))scene.value=cat;$('layer').hidden=!radar.maps[map.value].levels.lower;load()}
Object.keys(radar.maps).forEach(k=>map.add(new Option(k.slice(3),k)));map.onchange=select;scene.onchange=load;floor.onchange=picture;slider.oninput=draw;
$('play').onclick=()=>{if(timer){pause();return}if(slider.value===slider.max)slider.value=0;$('play').textContent='Пауза';timer=setInterval(()=>{slider.value=+slider.value+1;draw();if(slider.value===slider.max)pause()},250)};map.value='de_dust2';select();
